<!DOCTYPE html>
<html lang="en">
<head>
  <title>The Maza Hotel.Com</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link href="css/style.css"rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css?family=Abril+Fatface" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body style="margin-top:50px;">
<?php
      include('Menu Bar.php')
  ?><br>
<div class="container-fluid text-center">
<div class="container"> 
  <div class="row content">
    <div class="col-sm-12">
	<h6>THE PROPERTY</h6>
<h2 id="font">THE MAZA HOTEL MANGALORE</h1>
      <p class="text-justify">The Maza hotel at Mangalore, one of the finest from The maza stable, stands true to its name with architecture,
 hospitality and an experience as rare and exquisite as the pristine pearl in the ocean. It is conceptualized and developed to cater to the leisure travelers, 
business travelers and those looking for corporate and family events alike.</p>
<h1 align="center"id="font">[ Services ]</h1><br>
<p class="text-justify">The Maza Hotel often provide a wide array of guest services and on-site facilities. Commonly found amenities may include: on-site food and beverage (room service and restaurants), meeting and conference services and facilities, fitness center, and business center. Full-service hotels range in quality from mid-scale to luxury. This classification is based upon the quality of facilities and amenities offered by the hotel.</p>
    </div>
  </div><br><br>
  <div class="row"align="center">
	  <div class="col-sm-2"style="background-color:#27303b;height:80px;width:100px;">
            <a href="event.php"><img src="image/icon/ic1.png"width="95px;"height="75px;"style="margin-top:15px;"></a>
        </div>
        <div class="col-sm-2">
          <h4><b>Event</b></h4>
        </div>
        <div class="col-sm-2"style="background-color:#27303b;height:80px;width:100px;">
            <a href="spa.php"><img src="image/icon/ic2.png"width="95px;"height="75px;"style="margin-top:15px;"></a>
        </div>
         <div class="col-sm-2">
          <h4><b>Spa & Wellness </b></h4>
        </div>
	    <div class="col-sm-2"style="background-color:#27303b;height:80px;width:100px;">
            <a href="restaurant.php"><img src="image/icon/ic3.png"width="95px;"height="75px;"style="margin-top:15px;"></a>
        </div>
         <div class="col-sm-2">
          <h4><b>Restaurant</b></h4>
        </div>
  </div><br><br>
</div>
</div>
<?php
  include('Footer.php')
?>
</body>
</html>
