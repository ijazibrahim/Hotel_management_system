<!DOCTYPE html>
<html lang="en">
<head>
  <title>The Maza Hotel.Com</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link href="css/style.css"rel="stylesheet"/>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body style="margin-top:50px;">
<?php
      include('Menu Bar.php')
  ?>
<div class="container-fluid text-center">
<div class="container"> 
<h1>EVENT VENUES</h1>
<h1 id="font">EVENT VENUES</h1><br>
</br>
</div>
<h4>Weddings</h4>
<p>Ocean Pearl has multi-farious options for you 
to host a dream wedding with grand halls, well-equipped banquets and all the accoutrements essential to make the event magnificent and memorable.</p>
<br/>
<h4>Meeting & Conferences</h4>
<p>Dedicated Conference Halls 
and Meeting Rooms are furnished with adequate facilities to plan all types of corporate meetings, brainstorming sessions and other formal and informal functions.</p>
<br/>
<div class="hr">
<hr/ width="1045">
<br/>
</div>
<div class="block">
<div class="img">
<img src="img21.png" alt="" width="750" height="300"/>
<img src="img22.png" alt="" width="750" height="300"/>
<img src="img23.png" alt="" width="750" height="300"/>
</div>
</div>
</div>
</div>
<?php
  include('Footer.php')
?>
</div>
</body>
</html>