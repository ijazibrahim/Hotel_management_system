<!DOCTYPE html>
<html lang="en">
<head>
  <title>The Maza Hotel.Com</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link href="css/style.css"rel="stylesheet"/>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body style="margin-top:50px;">
<?php
      include('Menu Bar.php')
  ?>
<div class="container-fluid text-center">
<div class="container"> 
<h1 id="font">Restaurant's</h1><br>
<p>The MAZA Hotel Mangalore offers a wide array of eating options from coffee shop to fine dine, 
from pure vegetarian to lounge and bar. Enjoy the great variety of cuisines while your stay and have some gala time.</p>
<br/>
<br/>
<div class="block">
<br/>
<div class="img">
<img src="img28.png" alt="" width="750" height="250"/>
<hr/ width="750">
<img src="img29.png" alt="" width="750" height="250"/>
<hr/ width="750">
<img src="img30.png" alt="" width="750" height="250"/>
<hr/ width="750">
<img src="img31.png" alt="" width="750" height="250"/>
</div>
</div>
</div>
</div>
</body>
<br/>
<br/>
<?php
  include('Footer.php')
?>
</div>
</body>
</html>