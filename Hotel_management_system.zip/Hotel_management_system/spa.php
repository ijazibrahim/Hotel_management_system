<!DOCTYPE html>
<html lang="en">
<head>
  <title>The Maza Hotel.Com</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link href="css/style.css"rel="stylesheet"/>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body style="margin-top:50px;">
<?php
      include('Menu Bar.php')
  ?>
<div class="container-fluid text-center">
<div class="container"> 
<h1 id="font">Spa & Wellness</h1><br>
<p>MAZA Hotel Spa and Wellness Centre offers a right mix of ayurvedic and modern therapeutic techniques. From Signature experiences to ayurvedic body treatments and beauty solutions,
 we ensure that clients experience a sojourn of great rejuvenation and a short but memorable escape from the rigmarole of life and work.</p>
<br/>
<br/>
<div class="block">
<br/>
<div class="img">
<img src="img27.png" alt="" width="750" height="250"/>
<hr/ width="750">
<img src="img26.png" alt="" width="750" height="250"/>
<hr/ width="750">
<img src="img25.png" alt="" width="750" height="250"/>
<hr/ width="750">
<img src="img24.png" alt="" width="750" height="250"/>
</div>
</div>
</div>
</div>
</body>
<br/>
<br/>
<?php
  include('Footer.php')
?>
</div>
</body>
</html>